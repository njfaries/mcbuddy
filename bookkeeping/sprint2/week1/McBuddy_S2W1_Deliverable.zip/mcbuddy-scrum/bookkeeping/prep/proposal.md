ECSE 428 Winter 2015

Team/Project: McBuddy

Our project is to create a mobile application to match McGill students with study partners. Users can input their list of courses and preferences to obtain a list of matched students who can be contacted via the application.

Ryan Ordille - 260399372 ryan.ordille@mail.mcgill.ca
Lilly Tong - 260459522 lilly.tong@mail.mcgill.ca
Yuechuan Chen  - 260504371 yuechuan20@gmail.com
Nicholas Aird - 260533580 nicholas.aird@mail.mcgill.ca
Carl Patenaude Poulin - 260482798 carl.patenaudepoulin@mail.mcgill.ca
Nathaniel Faries - 260456371 nathaniel.faries@mail.mcgill.ca
Han Yang Zhao -260534081 han.y.zhao@mail.mcgill.ca
Amee Joshipura - 260461226 amee.joshipura@mail.mcgill.ca