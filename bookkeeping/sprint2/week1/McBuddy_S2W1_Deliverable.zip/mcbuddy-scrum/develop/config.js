var QBAPP = {
    appID: 18579 ,
    authKey: "FUrJ5hSsYfaqZt3" ,
    authSecret: "AOpwfgLYMzO3X9q",
    publicRoom: 'public',
    debug: true
}

